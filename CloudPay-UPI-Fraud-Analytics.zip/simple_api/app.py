from flask import Flask, request, jsonify
from flask_cors import CORS
import sqlite3
from datetime import datetime
import csv
import os

app = Flask(__name__)
CORS(app)

DB_FILE = "upi.db"
CSV_FILE = "transactions.csv"

# =========================
# DATABASE SETUP
# =========================

def setup_database():

    conn = sqlite3.connect(DB_FILE)

    cur = conn.cursor()

    cur.execute("""

    CREATE TABLE IF NOT EXISTS transactions (

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        sender TEXT,

        receiver TEXT,

        amount REAL,

        status TEXT,

        fraud_flag TEXT,

        payment_type TEXT,

        location TEXT,

        txn_time TEXT,

        year TEXT,

        month TEXT

    )

    """)

    conn.commit()

    conn.close()

    # CSV HEADER

    if not os.path.exists(CSV_FILE):

        with open(CSV_FILE, "w", newline="") as file:

            writer = csv.writer(file)

            writer.writerow([

                "id",

                "sender",

                "receiver",

                "amount",

                "status",

                "fraud_flag",

                "payment_type",

                "location",

                "txn_time",

                "year",

                "month"

            ])

setup_database()

# =========================
# FRONTEND
# =========================

@app.route("/")
def home():

    return """

<!DOCTYPE html>

<html>

<head>

<title>CloudPay</title>

<style>

body{

margin:0;

height:100vh;

background:linear-gradient(135deg,#26113F,#4c1d95,#7c3aed);

display:flex;

justify-content:center;

align-items:center;

font-family:Arial;

overflow:hidden;

}

.card{

width:450px;

padding:35px;

border-radius:30px;

background:rgba(255,255,255,0.18);

backdrop-filter:blur(20px);

box-shadow:0 20px 50px rgba(0,0,0,0.3);

text-align:center;

color:white;

}

h1{

font-size:40px;

margin-bottom:5px;

}

input,select,button{

width:100%;

padding:15px;

margin-top:15px;

border:0;

border-radius:15px;

font-size:16px;

}

button{

background:white;

color:#6d28d9;

font-weight:bold;

cursor:pointer;

}

.fly-area{

height:130px;

position:relative;

overflow:hidden;

}

.bird,.bag{

position:absolute;

right:-80px;

font-size:45px;

}

.bird{

top:35px;

}

.bag{

top:55px;

right:-35px;

}

.fly{

animation:fly 3s linear forwards;

}

@keyframes fly{

from{right:-80px;}

to{right:460px;}

}

#result{

margin-top:20px;

padding:15px;

border-radius:15px;

background:white;

color:#6d28d9;

font-size:24px;

font-weight:bold;

min-height:35px;

}

</style>

</head>

<body>

<div class="card">

<h1>CloudPay</h1>

<p>Live UPI Payment Tracker</p>

<input id="sender" placeholder="Sender Name">

<input id="receiver" placeholder="Receiver Name">

<input id="amount" type="number" placeholder="Amount">

<select id="payment_type">

<option>UPI</option>

<option>Wallet</option>

<option>Credit Card</option>

<option>Debit Card</option>

<option>Net Banking</option>

</select>

<input id="location" placeholder="Location">

<button onclick="pay()">Transfer Money</button>

<div class="fly-area">

<span class="bird">🕊️</span>

<span class="bag">💰</span>

</div>

<div id="result">

Result will appear here

</div>

</div>

<script>

function pay(){

let sender=document.getElementById("sender").value;

let receiver=document.getElementById("receiver").value;

let amount=document.getElementById("amount").value;

let payment_type=document.getElementById("payment_type").value;

let location=document.getElementById("location").value;

let bird=document.querySelector(".bird");

let bag=document.querySelector(".bag");

let result=document.getElementById("result");

result.innerText="Processing payment...";

bird.classList.remove("fly");

bag.classList.remove("fly");

void bird.offsetWidth;

bird.classList.add("fly");

bag.classList.add("fly");

fetch("/pay",{

method:"POST",

headers:{

"Content-Type":"application/json"

},

body:JSON.stringify({

sender:sender,

receiver:receiver,

amount:amount,

payment_type:payment_type,

location:location

})

})

.then(res=>res.json())

.then(data=>{

setTimeout(()=>{

result.innerText=data.message;

result.style.color=

data.status==="SUCCESS"

?"green"

:"red";

},3000);

})

.catch(error=>{

result.innerText="Payment Error";

result.style.color="red";

});

}

</script>

</body>

</html>

"""

# =========================
# PAYMENT API
# =========================

@app.route("/pay", methods=["POST"])
def pay():

    try:

        data = request.json

        sender = data.get("sender", "Unknown")

        receiver = data.get("receiver", "Unknown")

        amount = float(data.get("amount", 0))

        payment_type = data.get("payment_type", "UPI")

        location = data.get("location", "Chennai")

        status = "FAILED" if amount > 10000 else "SUCCESS"

        fraud_flag = "YES" if amount > 8000 else "NO"

        txn_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        year = datetime.now().strftime("%Y")

        month = datetime.now().strftime("%B")

        message = (

            "Payment Failed"

            if status == "FAILED"

            else "Payment Successful"

        )

        conn = sqlite3.connect(DB_FILE)

        cur = conn.cursor()

        cur.execute("""

        INSERT INTO transactions

        (

            sender,

            receiver,

            amount,

            status,

            fraud_flag,

            payment_type,

            location,

            txn_time,

            year,

            month

        )

        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)

        """,

        (

            sender,

            receiver,

            amount,

            status,

            fraud_flag,

            payment_type,

            location,

            txn_time,

            year,

            month

        )

        )

        conn.commit()

        txn_id = cur.lastrowid

        conn.close()

        # SAVE CSV

        with open(CSV_FILE, "a", newline="") as file:

            writer = csv.writer(file)

            writer.writerow([

                txn_id,

                sender,

                receiver,

                amount,

                status,

                fraud_flag,

                payment_type,

                location,

                txn_time,

                year,

                month

            ])

        return jsonify({

            "message": message,

            "status": status,

            "fraud_flag": fraud_flag,

            "txn_time": txn_time

        })

    except Exception as e:

        print("ERROR:", e)

        return jsonify({

            "message": "Backend Error",

            "status": "FAILED"

        })

app.run(debug=True, use_reloader=False)