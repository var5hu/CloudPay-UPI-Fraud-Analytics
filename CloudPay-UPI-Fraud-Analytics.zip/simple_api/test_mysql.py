print("Step 1 started")

try:
    import mysql.connector
    print("Step 2 imported")

    conn = mysql.connector.connect(
        host="localhost",
        port=3306,
        user="root",
        password="Cartoon@14",
        database="simple_upi",
        connection_timeout=5
    )

    print("Step 3 connected")
    conn.close()

except Exception as e:
    print("MYSQL ERROR:")
    print(e)