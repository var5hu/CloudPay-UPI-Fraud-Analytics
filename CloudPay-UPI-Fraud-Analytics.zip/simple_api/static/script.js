function makePayment() {
    const sender = document.getElementById("sender").value;
    const receiver = document.getElementById("receiver").value;
    const amount = document.getElementById("amount").value;

    const bird = document.querySelector(".bird");
    const bag = document.querySelector(".bag");
    const result = document.getElementById("result");

    result.innerText = "";

    bird.classList.remove("fly");
    bag.classList.remove("fly");

    void bird.offsetWidth;

    bird.classList.add("fly");
    bag.classList.add("fly");

    fetch("/pay", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            sender: sender,
            receiver: receiver,
            amount: amount
        })
    })
    .then(response => response.json())
    .then(data => {
        setTimeout(() => {
            result.innerText = data.message;

            if (data.status === "SUCCESS") {
                result.style.color = "#bbf7d0";
            } else {
                result.style.color = "#fecaca";
            }
        }, 3000);
    });
}